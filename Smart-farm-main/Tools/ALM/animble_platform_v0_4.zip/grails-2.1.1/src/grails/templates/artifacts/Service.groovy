@artifact.package@class @artifact.name@ {

    def serviceMethod() {

    }
}
