@artifact.package@

import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.services.ServiceUnitTestMixin} for usage instructions
 */
@TestFor(@artifact.testclass@)
class @artifact.name@ {

    void testSomething() {
        fail "Implement me"
    }
}
