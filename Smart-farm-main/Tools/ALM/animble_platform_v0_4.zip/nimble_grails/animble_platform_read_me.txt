Welcome to aNimble Platform!

For installation instructions, user forums and more, please visit:

http://animbleplatform.ideastub.com

For information on has what has changed since the last release, please visit:

animble_platform_release_notes.txt